# J.A.R.V.I.S. Android

This package wraps the existing JARVIS HTML interface as an Android application using Capacitor and builds a debug APK through GitHub Actions.

## Build the APK

1. Upload the contents of this folder to the root of your GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build JARVIS Android APK** and tap **Run workflow**.
4. When the workflow completes, open the run and download the `jarvis-debug-apk` artifact.
5. Extract the ZIP and install `app-debug.apk` on your Android phone.

A push that changes `index.html` also triggers a build.

## Current scope

This is the first Android packaging stage. It wraps the existing HTML interface; it does not yet provide a persistent wake-word service or privileged system controls. Native integrations will be added and tested in later stages.

Do not commit API keys or signing credentials. The current HTML asks the user to enter a Gemini key locally.
