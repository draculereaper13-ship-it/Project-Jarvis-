const fs = require("fs");
const path = require("path");

const source = path.join(__dirname, "..", "index.html");
const targetDir = path.join(__dirname, "..", "www");
const target = path.join(targetDir, "index.html");

if (!fs.existsSync(source)) {
  console.error("Missing index.html. Add your existing JARVIS interface to the repository root.");
  process.exit(1);
}
fs.mkdirSync(targetDir, { recursive: true });
fs.copyFileSync(source, target);
console.log("Copied index.html into www/ for Capacitor.");
